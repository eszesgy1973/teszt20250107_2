<?php
$pizzak=array("sonkas"=>"Sonkás" , "gyros"=>"Gyrosos" , "negy"=>"Négy évszak");

echo( $pizzak["negy"]."<HR>" );

//új elem hozzáadása
$pizzak["hawaii"]="Hawaii";

//tömb bejárása
foreach( $pizzak as $idx=>$item )
{
	//echo($idx." : ".$item."<BR>");
	echo($item."<BR>");
}

?>