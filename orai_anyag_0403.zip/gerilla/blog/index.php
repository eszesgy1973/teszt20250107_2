<?php
session_start();

if( isset( $_GET["logout"] ) )
{
	session_unset();
}
?>
<!doctype html>
<html>
	<head>
		<title>Egyszerű blog ,text file kezelés</title>
		<link rel="stylesheet" type="text/css" href="css/stilus.css">
		<meta charset="utf-8">
	</head>
	<body>
		<div class="felso_doboz">
			<?php
				if( isset($_SESSION["admin"]) )
				{
					echo("Üdv: Admin<BR><a href='index.php?logout=1'>Kilépés</a>");
					
					include("modulok/uj_bejegyzes.php");
				}
				else
				{
					include("modulok/belepes.php");
				}
			?>
		</div>
		
		<div class="hozzaszolas_doboz">
			<?php
				include("modulok/hozzaszolas_lista.php");
			?>
		</div>
	</body>
</html>