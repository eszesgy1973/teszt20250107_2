<?php
if( trim($_POST["ujcim"])!="" and trim($_POST["ujszoveg"])!="" )
{
	//echo("Mehet");
	
	//A fájl megnyitása hozzáírásra
	$fm=fopen("../blog.txt","a"); //r - olvasásra , a - hozzáírásra , w - teljes újraírásra nyitja a fájlt
	
	//$fm -> fájlmutató ami a fájl megnyitását követően kap értéket és ezt követően a fájlműveletekhez ezt kell használni
	
	$cim=str_replace(";","",$_POST["ujcim"]);
	
	$cim=str_replace("||","",$cim);
	
	$szoveg=str_replace(";","",$_POST["ujszoveg"]);
	
	$szoveg=str_replace("||","",$szoveg);
	
	$beir_szoveg=trim($cim).";".trim($szoveg).";".date("Y.m.d H:i")."||";
	//maszk karakter -> Y -> év 4 karakterrel , m -> hónap , d -> nap , h -> óra , i -> perc
	
	fwrite($fm , $beir_szoveg); //fájlmutató , szöveg
	
	fclose($fm); //fájl lezárása
	
	//echo("A mentés megtörtént!<BR><A href='../index.php'>Vissza</A>");
	header("Location:../index.php");
}
else
{
	echo("A cím és/vagy tartalom nem lehet üres!");
	echo("<BR><A href='../index.php'>Vissza</A>");
}
?>