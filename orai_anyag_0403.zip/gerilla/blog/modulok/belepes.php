<form action="modulok/belepellenor.php" autocomplete="false" method="POST">
	<input type="password" name="jelszo" placeholder="Jelszó..." value="">
	<input type="submit" Value="Belépés">
</form>