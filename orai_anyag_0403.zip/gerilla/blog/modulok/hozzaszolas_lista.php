<?php
//megnézzük,hogy létezik-e a hozzászólásokat tároló text állomámy
if( !file_exists("blog.txt") ) //file_exists -> fájlok létezésének vizsgálata
{
	//fájl létrehozása
	touch("blog.txt");
}

//echo("Eddig jó!");

$blog_szoveg=file_get_contents("blog.txt");

if( strlen($blog_szoveg)==0 ) //strlen -> szöveg hosszának meghatározása -> karakterek száma
{
	echo("Jelenleg még nincs bejegyzés!");
}
else
{
	//echo($blog_szoveg);
	
	$bejegyzesek=explode("||",$blog_szoveg);
	
	echo("<DIV class='blog_bejegyzesek_szama'>Bejegyzések száma:".(count($bejegyzesek)-1)."</DIV>");
	
	$bejegyzesek=array_reverse($bejegyzesek); //tömb megfordítása
	
	foreach( $bejegyzesek as $egybejegyzes )
	{
		if($egybejegyzes!="")
		{
			echo("<DIV class='bejegyzes_doboz'>");
			
			//echo($egybejegyzes);
			$adatok=explode(";",$egybejegyzes);
				echo("<DIV class='bejegyzes_fejlec'>");
					echo("<DIV class='fejlec_bal'>");
						echo($adatok[0]);
					echo("</DIV>");
					echo("<DIV class='fejlec_jobb'>");
						echo($adatok[2]);
					echo("</DIV>");
				echo("</DIV>");
			
				echo("<DIV class='blog_tartalom'>");
						echo( str_replace("\n","<BR>",$adatok[1]) );
				echo("</DIV>");
			
			echo("</DIV>");
		}
	}
}


?>