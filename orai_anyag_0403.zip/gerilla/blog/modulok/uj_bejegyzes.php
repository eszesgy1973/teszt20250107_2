<?php
if(isset($_SESSION["admin"]))
{
?>

<FORM action="modulok/bejegyzes_ment.php" method="POST">
<input type="text" class="urlapmezo" name="ujcim" placeholder="Bejegyzés címe...">

<textarea name="ujszoveg" class="urlapmezo tobbsoros" placeholder="Bejegyzés szövege..."></textarea>
<BR>
<input type="submit" Value="Mentés">
</FORM>

<?php
}
?>