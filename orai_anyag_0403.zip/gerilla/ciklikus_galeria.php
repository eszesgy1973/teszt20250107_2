<link rel="stylesheet" type="text/css" href="css/stilus.css">

<form enctype="multipart/form-data" action="feltoltes.php" method="POST">
Kép feltöltése az albumba:<BR>
<input type="file" name="kep">
<input type="submit" value="Feltöltés">
</form>
<HR>
<?php
//mappa megnyitása
$mappa=opendir("kepek");

//fájl vagy mappa bejegyzés kiolvasása
/*
$fajl=readdir($mappa); //a következő bejegyzést olvassa ki 

echo( $fajl );

$fajl=readdir($mappa); //a következő bejegyzést olvassa ki 

echo( "<BR>".$fajl );
*/

while( $fajl=readdir($mappa) ) // $fajl=readdir($mappa) -> ennek a függvénynek a hívása false értéket eredményez abban az esetben ,ha elértük az utolsó bejegyzést
{
	//echo( $fajl."<BR>" );
	if( $fajl!="." and $fajl!=".." )
	{
		echo("<IMG src='kepek/".$fajl."' class='kiskep'>");
	}
}

?>