<?php
//while vagy elől tesztelő ciklus
/*
while(feltétel) //ha a feltétel igaz akkor hajta végre a ciklusmagot ,majd visszafut
{
	ciklus mag;
}
*/

$szam=1;

while( $szam<=100 )
{
	echo($szam." , ");
	
	$szam++; //az adott numerikus változó értékét 1-el növeli 
}

?>