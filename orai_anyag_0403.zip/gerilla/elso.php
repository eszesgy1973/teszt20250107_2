<?php
/*a php kód eleje*/
/*utasítások*/

/*kimenetek*/
echo("Első PHP programom!");

//ez is egy komment csak 1 soros
/*php kód vége*/
?>