<?php
//megnézzük,hogy milyen paraméterket kapott a script
// a POST metódussal küldött adatok a $_POST tömbbe érkeznek
//print_r($_POST); //print_r -> alkalmas arra,hogy összetett adattartalmak is visszaadhatóak legyenek

$vnev=$_POST["vnev"];
$knev=$_POST["knev"];

echo("Üdv: ".$vnev." ".$knev);
 
?>