<?php
//a feltöltött adott űrlap azonosítóval rendelkező fájl adatainak elérése
//print_r( $_FILES["kep"] );

if( $_FILES["kep"]["type"] == "image/jpeg" or $_FILES["kep"]["type"] == "image/png" )
{
	//átmozgatom a fájlt az átmeneti biztonságos mappából a végleges "kep" mappába
	move_uploaded_file( $_FILES["kep"]["tmp_name"] , "kepek/".$_FILES["kep"]["name"] );
	//honnan , hová és milyen néven

	//automatikus átirányítás egy tetszőleges modulra vagy url-readdir
	header("Location:ciklikus_galeria.php");
}
else echo("Csak jpeg vagy png tölthető fel!<BR><A href='ciklikus_galeria.php'>Vissza</A>");
?>