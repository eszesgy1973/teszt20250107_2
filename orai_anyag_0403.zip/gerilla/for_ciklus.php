<?php
for( $i=1 ; $i<100 ; $i+=2 ) // ciklusváltozó;végfeltétel;ciklus művelet ami minden visszatéréskor lefut
{
	//ciklusmag
	echo( $i." , " );
}
?>