<?php
$szavak=array(
			"dog"=>"Kutya",
			"cat"=>"Cica",
			"door"=>"Ajtó",
			"kitchen"=>"Konyha"
			);
?>

<FORM action="fordito.php" method="POST">
<input type="text" name="angol" placeholder="Angol...">
<input type="submit" Value="Fordítás magyarra">
</FORM>

<?php
if( isset($_POST["angol"]) )
{
	$keres_szo=$_POST["angol"];
	//megnézem,hogy létezik-e a $szavak tömbben az adott sazonosítóval rendelkező tömbelem
	if( isset( $szavak[$keres_szo] ) )
	{
		echo("<HR>".$keres_szo." : ".$szavak[$keres_szo]);
	}
	else
	{
		echo("<HR>Nincs ilyen angol szó az adatbázisban! (".$keres_szo.")");
	}
}
?>