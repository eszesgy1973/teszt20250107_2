<?php

if( !isset($_POST["tipp"]) )
{
	$titkos=rand(1,100); //rand -> véletlenszám generálása mettől,meddig

	echo("<DIV>Gondoltam egy számra 1-100-ig!Tippelj!</DIV>");
	
	$tippek_szama=0;
}
else
{
	//echo( $_POST["tipp"].",".$_POST["titkos"]."<BR>" );
	
	if( $_POST["tipp"]>$_POST["titkos"] ) echo("Kisebbre gondoltam!");
	
	if( $_POST["tipp"]<$_POST["titkos"] ) echo("Nagyobbra gondoltam!");
	
	if( $_POST["tipp"] == $_POST["titkos"] )
	{
		echo("Gratulálunk eltaláltad!!");
		
		$talalat=true;
		
		echo("<BR><A href='gondoltam.php'>Új játék</A>");
	}
	
	$titkos=$_POST["titkos"];
	
	$tippek_szama=$_POST["tippszam"]+1;
}

//echo($titkos);

echo("Tippek száma: ".$tippek_szama);
?>

<?php
if( !isset($talalat) )
{
?>

<HR>
<FORM action="gondoltam.php" method="POST">
<INPUT type="number" name="tipp" placeholder="Tipp...">
<INPUT type="hidden" name="titkos" value="<?php echo($titkos) ?>">
<INPUT type="hidden" name="tippszam" value="<?php echo($tippek_szama) ?>">
<INPUT type="submit" Value="Mehet">
</FORM>

<?php
}
?>