$(document).ready(
function()
{
	$(".szamgomb").click(
	function()
	{
		//a kattintott gombról leveszem a click eseménykezelőt
		//$(this).unbind("click");
		
		if( $("#kihuzott_szamok").find(".g_"+$(this).data("sorszam")).length>0 )
		{
			alert("Engem már választottál!");
		}
		
		
		if( !$(this).hasClass("kivalasztott") && $("#kihuzott_szamok").find(".szamgomb").length<5 )
		{
			$(this).css({"background-color":"green"});
			
			$("<button class='szamgomb g_"+$(this).data("sorszam")+"'>"+$(this).html()+"</button>").appendTo( $("#kihuzott_szamok") ).click(
			function()
			{
				$(this).remove(); //remove() -> az objektum fizikalilag ürül a memóriából
			});
		}
		
		$(this).addClass("kivalasztott");
	});
});