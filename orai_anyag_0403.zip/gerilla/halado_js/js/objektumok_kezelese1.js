//document -> teljes felhasználói objektumhalmazt magában hordozza
$(document).ready(
	function() //ez a függvény fut le amikor az adott pl.ready esemény keletkezik
	{
		//utasítások
		//alert("Betöltés megtörtént!");
		$(".gomb1").click(
		function()
		{
			//tartalom felülírása
			$(".gomb1").html("Mentés");
			
			//design megváltoztatása
			if( !$(".gomb1").hasClass("ujgomb") ) //ha nem tagja a gomb1 az ujgomb osztálynak?
				$(".gomb1").addClass("ujgomb");
			else
			{
				$(".gomb1").removeClass("ujgomb");
				$(".gomb1").html("GOMB");
			}
			
			//az objektum futásidőben történő létrehozása
			var generalt_gomb = $("<BUTTON class='runtime_gomb'>Én egy futásidőben létrehozott gomb vagyok</BUTTON>").appendTo( $("body") );
			//az objektum memóriában történő létrehozását követően meg kell határozni,hogy melyik már létező objektum lesz az un. szülője vagyis milyen container-en belül vizualizálja
			
			generalt_gomb.click(
			function()
			{
				//az a bizonyos gomb amelyiken az esemény keletkezett
				$(this).addClass("ujgomb");
			});
			
			$(".gomb2").click(
			function()
			{
				$(".runtime_gomb").css(
				{
					"margin":"25px"
				});
			});
			
		});
	}
);