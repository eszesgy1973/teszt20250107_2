<!doctype html>
<html>
	<head>
		<title>Objektumok elérése és kezelése JS-ben</title>
		<link rel="stylesheet" type="text/css" href="css/stilus.css">
		
		<meta charset="utf-8">
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
	
		<script type="text/javascript" src="jquery/jquery-1.8.2.js">
		</script>
	
		<script type="text/javascript" src="jquery/jquery-ui-1.9.1.custom.js">
		</script>
		
		<script type="text/javascript" src="js/objektumok_kezelese1.js">
		</script>
	
	</head>
	<body>
		<button class="gomb1">GOMB</button>
		
		<button class="gomb2">Futásidejű gombok eltávolítása egymástól</button>
		
	</body>
</html>
	
	
	