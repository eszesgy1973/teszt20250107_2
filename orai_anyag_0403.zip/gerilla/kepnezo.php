<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<?php
//ami a php tag-en kívül van az értelmezés nélkül változatlan formában érkezik meg a kliens böngészőbe

echo("<DIV style='overflow:auto'><A class='link1' href='kepnezo.php?kep=kep1.jpg'>Kutya1</A>");
echo("<A class='link1' href='kepnezo.php?kep=kep2.jpg'>Kutya2</A>");
echo("<A class='link1' href='kepnezo.php?kep=kep3.jpg'>Kutya3</A></DIV>");

echo("<HR>");

// változó vagy átadott paraméter létezésének vizsgálata -> isset( paraméter) -> true értékkel tér vissza ,ha a változó létezik és false ha nem
if( isset($_GET["kep"]) ) //ha a feltétel igaz vagyis létezik a $_GET["kep"] akkor lefut az elágazás magja
{
	echo("<IMG src='kepek/".$_GET["kep"]."' class='nagykep'>");
}

?>