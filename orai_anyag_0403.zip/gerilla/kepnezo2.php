<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<DIV style='overflow:auto'>
	<A class='link1' href='kepnezo2.php?kep=kep1.jpg'>Kutya1</A>
	<A class='link1' href='kepnezo2.php?kep=kep2.jpg'>Kutya2</A>
	<A class='link1' href='kepnezo2.php?kep=kep3.jpg'>Kutya3</A>
</DIV>

<?php
//ami a php tag-en kívül van az értelmezés nélkül változatlan formában érkezik meg a kliens böngészőbe
echo("<HR>");

// változó vagy átadott paraméter létezésének vizsgálata -> isset( paraméter) -> true értékkel tér vissza ,ha a változó létezik és false ha nem
if( isset($_GET["kep"]) ) //ha a feltétel igaz vagyis létezik a $_GET["kep"] akkor lefut az elágazás magja
{
	echo("<IMG src='kepek/".$_GET["kep"]."' class='nagykep'>");
}

?>