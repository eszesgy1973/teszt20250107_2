<?php
$kapcsolat=new mysqli("localhost","root","","gerilla");

$kapcsolat->query("set names utf8");
?>