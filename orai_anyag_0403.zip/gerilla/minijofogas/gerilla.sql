-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Már 20. 20:12
-- Kiszolgáló verziója: 10.4.20-MariaDB
-- PHP verzió: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `gerilla`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hirdetesek`
--

CREATE TABLE `hirdetesek` (
  `id` int(10) NOT NULL,
  `cim` varchar(200) CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `leiras` text CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `ar` int(10) NOT NULL,
  `hirdeto_id` int(6) NOT NULL,
  `aktiv` int(1) NOT NULL,
  `datum` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `hirdetesek`
--

INSERT INTO `hirdetesek` (`id`, `cim`, `leiras`, `ar`, `hirdeto_id`, `aktiv`, `datum`) VALUES
(1, 'Teszt', 'Teszt leírás', 400000, 3, 1, '2024-03-20 19:29:18'),
(2, 'Teszt2', 'Teszt leírás', 400000, 3, 1, '2024-03-20 19:29:55'),
(3, 'Teszt', 'etette', 100000, 3, 1, '2024-03-20 19:54:21');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hirdetesek_kategoriak`
--

CREATE TABLE `hirdetesek_kategoriak` (
  `id` int(10) NOT NULL,
  `kategoria_id` int(6) NOT NULL,
  `hirdetes_id` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `hirdetesek_kategoriak`
--

INSERT INTO `hirdetesek_kategoriak` (`id`, `kategoria_id`, `hirdetes_id`) VALUES
(1, 3, 1),
(2, 2, 2),
(3, 1, 3);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hirdetesek_kepek`
--

CREATE TABLE `hirdetesek_kepek` (
  `id` int(11) NOT NULL,
  `hirdetes_id` int(9) NOT NULL,
  `kep` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hirdetok`
--

CREATE TABLE `hirdetok` (
  `id` int(6) NOT NULL,
  `nev` varchar(50) CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `jelszo` varchar(32) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobilszam` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `hirdetok`
--

INSERT INTO `hirdetok` (`id`, `nev`, `jelszo`, `email`, `mobilszam`) VALUES
(1, 'Eszes Gyuri', '1f32aa4c9a1d2ea010adcf2348166a04', 'eszesgy@gmail.com', '06302480058'),
(2, 'Kiss Gizi', '1f32aa4c9a1d2ea010adcf2348166a04', 'user12@gmail.com', ''),
(3, 'Kiss Gizi', '1f32aa4c9a1d2ea010adcf2348166a04', 'kissgizi@gmail.com', '06302480058');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kategoriak`
--

CREATE TABLE `kategoriak` (
  `id` int(5) NOT NULL,
  `megnevezes` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `icon` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `kategoriak`
--

INSERT INTO `kategoriak` (`id`, `megnevezes`, `icon`) VALUES
(1, 'Ingatlan', '<i class=\'fa fa-home\'></i>'),
(2, 'Autó', '<i class=\'fa fa-car\'></i>'),
(3, 'Háztartás', '<i class=\'fa-solid fa-couch\'></i>'),
(4, 'Ruházat', '<i class=\'fa fa-shopping-bag\'></i>'),
(5, 'Számítástechnika', '<i class=\'fa fa-laptop\'></i>');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `telefonkonyv`
--

CREATE TABLE `telefonkonyv` (
  `id` int(6) NOT NULL,
  `nev` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `mobil` varchar(15) NOT NULL,
  `cim` varchar(200) CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci NOT NULL,
  `munkahelyi` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- A tábla adatainak kiíratása `telefonkonyv`
--

INSERT INTO `telefonkonyv` (`id`, `nev`, `mobil`, `cim`, `email`, `munkahelyi`) VALUES
(1, 'Kiss Istvánka', '06301235454', 'Érd', 'pista@gmail.com', ''),
(2, 'Nagy Krisztina', '4634643643', 'Monor', 'kriszta@gmail.com', ''),
(3, 'Nagy Győzí', '06302485566', 'Őrvényes', 'gyozike@gmail.com', ''),
(6, 'Alapi Lajos', 'r353535356', 'Szolnok', 'eszesgx@gmail.com', ''),
(7, 'Nagy Bálint', '255252525', 'Szolnok', 'geza@gmail.com', '');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `hirdetesek`
--
ALTER TABLE `hirdetesek`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `hirdetesek_kategoriak`
--
ALTER TABLE `hirdetesek_kategoriak`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `hirdetesek_kepek`
--
ALTER TABLE `hirdetesek_kepek`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `hirdetok`
--
ALTER TABLE `hirdetok`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `kategoriak`
--
ALTER TABLE `kategoriak`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `telefonkonyv`
--
ALTER TABLE `telefonkonyv`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `hirdetesek`
--
ALTER TABLE `hirdetesek`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `hirdetesek_kategoriak`
--
ALTER TABLE `hirdetesek_kategoriak`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `hirdetesek_kepek`
--
ALTER TABLE `hirdetesek_kepek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `hirdetok`
--
ALTER TABLE `hirdetok`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `kategoriak`
--
ALTER TABLE `kategoriak`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `telefonkonyv`
--
ALTER TABLE `telefonkonyv`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
