<?php
session_start();

if( isset( $_GET["logout"] ) )
{
	session_unset(); //fullos session tároló törlés
}

include("connect.php");
?>
<!doctype html>
<html>
	<head>
		<title>Egyszerű többtáblás PHP-MYSQL alkalmazás</title>
		<link rel="stylesheet" type="text/css" href="css/stilus.css">
		
		<meta charset="utf-8">
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
	
	</head>
	<body>
		<div class="felso_menu">
			<div class="felso_menu_belso">
				<div>
					<a href="index.php"><img src="images/logo.svg"></a>
				</div>
				<div>
					<?php
					if( isset($_SESSION["aktuser"] ) ) //sikeresen belépett
					{
						echo("Belépve : ".$_SESSION["aktuser"]["nev"]);
						echo("&nbsp;&nbsp;<a class='kilepes_gomb' href='index.php?logout=1'>Kilépés</a>");
						include("modules/usermenu.php");
					}
					else
					{
					?>
						<a href="#" class="felso_menupont v2">Üzleti csomagok</a>
						<a href="index.php?aloldal=regisztracio.php" class="felso_menupont">Regisztráció</a>
						<a href="index.php?aloldal=belepes.php" class="felso_menupont">Belépés</a>
					<?php
					}
					?>
				</div>
			</div>
		</div>
		
		<div class="felso_menu kategoria_menu">
			<div class="felso_menu_belso" style="justify-content:left">
				<?php
					include("modules/kategoriak_vissza.php");
				?>
			</div>
		</div>
		
		<div class="felso_menu kereso_doboz">
			<div class="felso_menu_belso" style="justify-content:left">
				<?php
					include("modules/osszetett_kereso.php");
				?>
			</div>
		</div>
		
		<div class="fotartalom">
			<?php
				if( isset($_GET["aloldal"]) ) //megnézem,hogy kapott-e a script egy aloldal nevű paramétert?
				{
					$aloldal=$_GET["aloldal"];
					
					include("modules/".$aloldal);
				}
				else
				{
					include("modules/kiemelt.php");
				}
			?>
		</div>
		
	</body>
</html>