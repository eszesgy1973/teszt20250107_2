<?php
session_start();

include("../connect.php");

$st=$kapcsolat->prepare("select * from hirdetok where email=? and jelszo=?");

$jelszo=md5(md5($_POST["beleppass"]));

$st->bind_param("ss",$_POST["belepemail"],$jelszo);

$st->execute();

//a lekérdezés eredményének visszakérése
$vissza=$st->get_result();

if( mysqli_num_rows($vissza) == 1 )
{
	//echo("ok");
	$sor=mysqli_fetch_assoc($vissza); //visszakéri sima asszociatív tömbbe a következő record-ot
	
	$_SESSION["aktuser"]=$sor;
	
	header("Location:../index.php");
}
else 
{	
	header("Location:../index.php?aloldal=belepes.php&login=error");
}
?>