<?php
if(isset($_SESSION))
{
	if(isset($_GET["login"]))
	{
	   echo("<div class='hibadoboz'>Sikertelen belépés!</div>");
	}
?>

<div class="urlap_doboz">
	
	<form action="modules/belepellenor.php" method="POST">
	<input type="email" name="belepemail" class="urlapmezo" placeholder="Email...">
	<input type="password" name="beleppass" class="urlapmezo" placeholder="Jelszó...">
	<input type="submit" Value="Belépés">
	</form>
</div>


<?php
}
?>