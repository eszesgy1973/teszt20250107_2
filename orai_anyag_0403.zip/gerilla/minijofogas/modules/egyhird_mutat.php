<?php
if(isset($_SESSION))
{
	$st=$kapcsolat->prepare("select hirdetesek.*,hirdetesek.id as 'hird_id',hirdetesek.cim as 'hird_cim' from hirdetesek_kategoriak inner join hirdetesek on hirdetesek_kategoriak.hirdetes_id=hirdetesek.id where hirdetesek.id=?");
	
	$st->bind_param("s",$_GET["id"]);
	
	$st->execute();
	
	$vissza=$st->get_result();
	
	echo("<div class='hirdlista_doboz'>");
	
	while( $sor=mysqli_fetch_array($vissza) )
	{
		echo("<div class='egyhird_doboz' style='width:75%'>");
			
			echo("<div class='egyhird_cim_doboz'>");
				echo($sor["cim"]);
			echo("</div>");
			
			echo("<div class='egyhird_kep_doboz'>");
				
				$vissza_kepek=$kapcsolat->query("select * from hirdetesek_kepek where hirdetes_id=".$sor["hird_id"]);
				
				if( mysqli_num_rows($vissza_kepek)>0 )
				{
					$sor_kep=mysqli_fetch_array($vissza_kepek);
		
					echo("<img src='hird_kepek/".$sor_kep["kep"]."' class='egyhird_kep'>");
				}
				else
				{
					echo("<img src='images/nophoto.jpg' class='egyhird_kep'>");
				}
				
			echo("</div>");
			
			echo("<div class='egyhird_ar_doboz'>");
				
				echo( number_format($sor["ar"],0,""," "). " Ft" );
					
			echo("</div>");
			
			echo("<div class='egyhird_cim_doboz'>");
				echo($sor["leiras"]);
			echo("</div>");
			
			echo("<div class='egyhird_cim_doboz'>");
				echo("Hírdetés feladva: ".$sor["datum"]);
			echo("</div>");
			
			//HF: Itt jelenjen meg a hírdetés feladójának neve és telefonszáma
			//A saját hírdetések megjelenítése hasonlóan mint a hírdetés lista
			
			//feladó összes adatának lekérdezése
			$vissza_felado=$kapcsolat->query("select * from hirdetok where id=".$sor["hirdeto_id"]);
			
			$sor_hirdeto=mysqli_fetch_array($vissza_felado);
			
			echo("<div class='egyhird_cim_doboz'>");
				echo("Hírdető: ".$sor_hirdeto["nev"]);
			echo("</div>");
			
			echo("<div class='egyhird_cim_doboz'>");
				echo("Telefonszám: <a class='telefonlink' href='tel:".$sor_hirdeto["mobilszam"]."'><i class='fa fa-phone'></i>&nbsp;".$sor_hirdeto["mobilszam"]."</a>");
			echo("</div>");
			
			
		echo("</div>");
	}
	
	echo("</div>");
}
?>