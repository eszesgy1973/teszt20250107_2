<?php
session_start();

if( isset($_SESSION["aktuser"] ) ) //sikeresen belépett
{
	include("../connect.php");

	$st=$kapcsolat->prepare("insert into hirdetesek (cim,leiras,ar,hirdeto_id,aktiv,datum) values(?,?,?,?,1,now())");

	$st->bind_param("ssdd",$_POST["hirdetes_cim"],$_POST["hirdetes_leiras"],$_POST["hirdetes_ar"],$_SESSION["aktuser"]["id"]);

	if( $st->execute() )
	{
		$vissza_max=$kapcsolat->query("select max(id) as 'maxid' from hirdetesek");
		
		$sor_max=mysqli_fetch_array($vissza_max);
		
		$st1=$kapcsolat->prepare("insert into hirdetesek_kategoriak (kategoria_id,hirdetes_id) values(?,?)");
		
		$st1->bind_param("dd",$_POST["hirdetes_kategoria"],$sor_max["maxid"]);
		
		$st1->execute();
		
		if( isset( $_FILES["hirdetes_kep"] ) )
		{
			if( $_FILES["hirdetes_kep"]["type"]=="image/jpeg" or $_FILES["hirdetes_kep"]["type"]=="image/png" )
			{
				$kit=".jpg";
				
				if( $_FILES["hirdetes_kep"]["type"]=="image/png" ) $kit=".png";
				
				$ujnev="kep".date("Ymdhis").$kit;
				
				move_uploaded_file($_FILES["hirdetes_kep"]["tmp_name"],"../hird_kepek/".$ujnev);
				
				//HF: megcsinálni,hogy a hirdetesek_kepek táblába új recordként bekerüljön a hirdetés azonosító és a kép fletöltés utáni fájlneve
				
				$st2=$kapcsolat->prepare("insert into hirdetesek_kepek (hirdetes_id,kep) values(?,?)");
		
				$st2->bind_param("ds",$sor_max["maxid"],$ujnev);
				
				$st2->execute();
			}
		}
		
		
		header("Location:../index.php?aloldal=sikeres_hird.php");
	}
	else
	{
		echo("Hiba!");
	}
}
?>