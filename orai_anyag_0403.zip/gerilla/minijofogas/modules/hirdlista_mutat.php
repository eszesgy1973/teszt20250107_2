<?php
if(isset($_SESSION))
{
	if( isset($_GET["kat"]) )
	{
		//kategória szűrés
		$st=$kapcsolat->prepare("select hirdetesek.*,hirdetesek.id as 'hird_id',hirdetesek.cim as 'hird_cim',kategoriak.megnevezes as 'kateg_neve' from hirdetesek_kategoriak inner join hirdetesek on hirdetesek_kategoriak.hirdetes_id=hirdetesek.id inner join kategoriak on hirdetesek_kategoriak.kategoria_id=kategoriak.id where kategoria_id=?");
		
		$st->bind_param("s",$_GET["kat"]);
	}
	else if( isset($osszetett_feltetel) )
	{
		$st=$kapcsolat->prepare("select hirdetesek.*,hirdetesek.id as 'hird_id',hirdetesek.cim as 'hird_cim' from hirdetesek_kategoriak inner join hirdetesek on hirdetesek_kategoriak.hirdetes_id=hirdetesek.id ".$osszetett_feltetel);
	}
	else
	{
		$st=$kapcsolat->prepare("select hirdetesek.*,hirdetesek.id as 'hird_id',hirdetesek.cim as 'hird_cim' from hirdetesek_kategoriak inner join hirdetesek on hirdetesek_kategoriak.hirdetes_id=hirdetesek.id where kiemelt='1'");
	}
	
	$st->execute(); //futtatja az SQL parancsot
	
	$vissza=$st->get_result(); //lekérdezés eredményhalmazát adja vissza
	
	if( isset($_GET["kat"]) )
	{
		$felirat="Hírdetések száma: ".mysqli_num_rows($vissza)." <B>(".$_GET["kat_neve"].")</B>";
	}
	else if( isset($osszetett_feltetel) )
	{
		$felirat="Találatok száma: ".mysqli_num_rows($vissza);
	}
	else $felirat="Kiemelt hírdetések:";
	
	echo( $felirat );
	
	echo("<div class='hirdlista_doboz'>");
	
	while( $sor=mysqli_fetch_array($vissza) )
	{
		echo("<div class='egyhird_doboz'>");
		
		echo("<a style='text-decoration:none' href='index.php?aloldal=egyhird_mutat.php&id=".$sor["hird_id"]."'>");
			
			echo("<div class='egyhird_cim_doboz'>");
				echo($sor["cim"]);
			echo("</div>");
			
			echo("<div class='egyhird_kep_doboz'>");
				
				$vissza_kepek=$kapcsolat->query("select * from hirdetesek_kepek where hirdetes_id=".$sor["hird_id"]);
				
				if( mysqli_num_rows($vissza_kepek)>0 )
				{
					$sor_kep=mysqli_fetch_array($vissza_kepek);
		
					echo("<img src='hird_kepek/".$sor_kep["kep"]."' class='egyhird_kep'>");
				}
				else
				{
					echo("<img src='images/nophoto.jpg' class='egyhird_kep'>");
				}
				
			echo("</div>");
			
			echo("<div class='egyhird_ar_doboz'>");
				
				echo( number_format($sor["ar"],0,""," "). " Ft" );
					
			echo("</div>");
			
		echo("</a></div>");
	}
	
	echo("</div>");
}
?>