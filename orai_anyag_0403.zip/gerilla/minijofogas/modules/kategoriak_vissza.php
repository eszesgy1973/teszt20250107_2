<?php
if(isset($_SESSION))
{

function adatok_vissza($kapcs , $tabla_neve)
{
	$v=$kapcs->query("select * from ".$tabla_neve);
	
	return $v;
}

$valasz=adatok_vissza($kapcsolat,"kategoriak");

while( $sor=mysqli_fetch_array($valasz) )
{
echo('<a href="index.php?aloldal=hirdlista_mutat.php&kat='.$sor["id"].'&kat_neve='.$sor["megnevezes"].' " class="kategoria_menupont">'.$sor['icon'].'&nbsp;&nbsp;'.$sor['megnevezes'].'</a>');
}

}
else echo("Nincs jogosultsága az oldal megtekintésére!");
?>


