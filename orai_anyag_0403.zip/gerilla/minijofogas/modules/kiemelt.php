<?php
if(isset($_SESSION))
{
	include("modules/hirdlista_mutat.php");
}
?>