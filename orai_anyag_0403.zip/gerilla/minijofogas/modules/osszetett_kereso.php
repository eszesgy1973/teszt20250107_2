<?php
if(isset($_SESSION))
{
	$kulcsszo="";
	$artol=0;
	$arig=0;
	
	if(isset($_GET["kereso_torles"]))
	{
		unset($_SESSION["kereso"]);
	}
	
	if( isset($_REQUEST["kulcs_szo"]) ) //REQUEST -> a POST és GET paraméterek egyaránt belekerülnek
	{
		$_SESSION["kereso"]=$_REQUEST;
	}
	
	if( isset( $_SESSION["kereso"] ) ) //ha van letárolt keresési feltételek
	{
		$kulcsszo=$_SESSION["kereso"]["kulcs_szo"];
		$artol=$_SESSION["kereso"]["artol"];
		$arig=$_SESSION["kereso"]["arig"];
		
		//feltétel öszeállítása a mysql számára
		// where cim like "%mosógép%" and ar>=1000 and ar<=2000
		
		$osszetett_feltetel="";
		
		if( trim($kulcsszo) != "" )
		{
			//ebben az esetben figyelembe veszem a kulcs_szo beviteli mezőben megadott karakterláncot
			$osszetett_feltetel=" where (cim like '%".trim($kulcsszo)."%' or leiras like '%".trim($kulcsszo)."%')";
		}
		
		if( $artol!="" and $artol!=0 )
		{
			if( $osszetett_feltetel=="" )
			{
				$osszetett_feltetel=" where ar>=".$artol;
			}
			else $osszetett_feltetel.=" and ar>=".$artol;
		}
		
		if( $arig!="" and $arig!=0 )
		{
			if( $osszetett_feltetel=="" )
			{
				$osszetett_feltetel=" where ar<=".$arig;
			}
			else $osszetett_feltetel.=" and ar<=".$arig;
		}
		
		//echo($osszetett_feltetel);
	}
	
?>
	<FORM action="index.php" method="POST">
	<input type="text" name="kulcs_szo" placeholder="Mit keresel..." class="kereso_mezo" value="<?php echo($kulcsszo) ?>">
	<input type="number" name="artol" placeholder="Ártól..." class="kereso_mezo" value="<?php echo($artol) ?>">
	<input type="number" name="arig" placeholder="Árig..." class="kereso_mezo" value="<?php echo($arig) ?>">
	<button type="submit"><i class="fa fa-search"></i></button>
	</FORM>
	
	<a href="index.php?kereso_torles=reset">Keresési feltételek törlése</a>
<?php
}
?>