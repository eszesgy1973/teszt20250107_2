<?php
if(isset($_SESSION))
{
	if( isset( $_SESSION["hibak"] ) )
	{
		foreach( $_SESSION["hibak"] as $egyhiba )
		{
			echo("<div class='hibadoboz'>");
			echo($egyhiba);
			echo("</div>");
		}
	}
	
	$nev="";
	$email="";
	
	if( isset($_SESSION["regadatok"]) )
	{
		$nev=$_SESSION["regadatok"]["regnev"];
		$email=$_SESSION["regadatok"]["regemail"];
	}
?>


<div class="urlap_doboz">
	<form action="modules/regment.php" method="POST">
	<input type="text" name="regnev" class="urlapmezo" placeholder="Név..." value="<?php echo($nev) ?>">
	<input type="email" name="regemail" class="urlapmezo" placeholder="Email..." value="<?php echo($email) ?>">
	<input type="password" name="regpass" class="urlapmezo" placeholder="Jelszó...">
	<input type="password" name="regpass2" class="urlapmezo" placeholder="Jelszó mégegyszer...">
	<input type="text" name="regmobil" class="urlapmezo" placeholder="Mobil...">
	<input type="submit" Value="Mentés">
	</form>
</div>

<?php
}
?>