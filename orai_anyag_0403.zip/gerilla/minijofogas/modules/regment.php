<?php
session_start();

include("../connect.php");

if( isset( $_POST["regnev"] ) )
{
	foreach( $_POST as $mezo => $ertek )
	{
		$_POST[$mezo]=trim($ertek);
	}
	
	$hiba=false;
	
	$_SESSION["hibak"]=array();
	
	if( trim($_POST["regnev"])=="" )
	{
		array_push( $_SESSION["hibak"] , "Név megadása kötelező!");
		
		$hiba=true;
	}
	
	if( trim($_POST["regemail"])=="" )
	{
		array_push( $_SESSION["hibak"] , "E-mail megadása kötelező!");
		
		$hiba=true;
	}
	
	if( $_POST["regpass"]=="" )
	{
		array_push( $_SESSION["hibak"] , "Jelszó kötelező!");
		
		$hiba=true;
	}
	
	if( $_POST["regpass"]!=$_POST["regpass2"] )
	{
		array_push( $_SESSION["hibak"] , "Jelszavak nem egyeznek!");
		
		$hiba=true;
	}
	
	
	if( $hiba ) //ha a $hiba nevű logikai változó értéke true
	{
		$_SESSION["regadatok"]=$_POST;
		
		header("Location:../index.php?aloldal=regisztracio.php");
	}
	else
	{
		unset($_SESSION["regadatok"]);
		
		//echo("Mehet!");
		$st = $kapcsolat->prepare("insert into hirdetok (nev,jelszo,email,mobilszam) values(?,?,?,?)");
		
		$jelszo=md5(md5($_POST["regpass"]));
		
		$st->bind_param("ssss",$_POST["regnev"],$jelszo,$_POST["regemail"],$_POST["regmobil"]);
		
		if( $st->execute() )
		{
			header("Location:../index.php?aloldal=sikeres_reg.php");
		}
		else echo("Hiba!");
	}
}
?>