<?php
if(isset($_SESSION["aktuser"]))
{
?>

<div class="sikeres_reg_doboz">
Hírdetését sikeresen feladta!
</div>


<?php
}
?>