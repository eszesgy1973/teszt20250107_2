<?php
if(isset($_SESSION))
{
?>

<div class="sikeres_reg_doboz">
Köszönjük,hogy regisztrált! Lépjen be!
</div>


<?php
}
?>