<?php
if( isset($_SESSION["aktuser"] ) ) //sikeresen belépett
{
?>

<div class="urlap_doboz">
	<form action="modules/hirdetesment.php" enctype="multipart/form-data" method="POST">
	<input type="text" name="hirdetes_cim" class="urlapmezo" placeholder="Hírdetés címe..." value="">
	
	<select name="hirdetes_kategoria" class="urlapmezo">
		<option value="0">Válasszon kategóriát</option>
		<?php
			$vissza_kateg=$kapcsolat->query("select * from kategoriak order by megnevezes");
			
			while($sor=mysqli_fetch_array($vissza_kateg))
			{
				echo("<option value='".$sor["id"]."'>".$sor["megnevezes"]."</option>");
			}
		?>
	</select>
	
	<textarea maxlength="400" class="urlapmezo" name="hirdetes_leiras" placeholder="Hírdetés leírása...(max.400 karakter)" rows="6" style="resize:none"></textarea>
	
	<input type="number" style="width:80%" min="0" max="10000000" name="hirdetes_ar" class="urlapmezo" placeholder="Irányár...(Ft)">&nbsp;Ft
	<BR>
	Kép:
	<BR>
	<input type="file" name="hirdetes_kep" class="urlapmezo" accept="image/*">
	
	<!--<input type="file" name="hirdetes_kep" class="urlapmezo" accept="*.jpg,*.png">--> 
	
	<input type="submit" Value="Hírdetés feladása">
	</form>
</div>

<?php
}
?>