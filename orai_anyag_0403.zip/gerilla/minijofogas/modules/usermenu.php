<?php
if( isset($_SESSION["aktuser"] ) ) //sikeresen belépett
{
?>
	<div><a href="index.php?aloldal=ujhirdetes.php">Hírdetés feladás</a></div>
	
	<div><a href="index.php?aloldal=sajat_hirdetesek.php">Hírdetéseim</a></div>


<?php
}
?>					