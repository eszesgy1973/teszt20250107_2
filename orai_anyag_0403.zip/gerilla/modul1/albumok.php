<?php
//unset( $_SESSION["albumok"] );

if( !isset($_SESSION["albumok"]) )
{
	/*$_SESSION["albumok"]=array(
		"album1"=>array("mappa"=>"kepek/album1","alias"=>"Nyári élmények")
		,
		"album2"=>array("mappa"=>"kepek/album2","alias"=>"Család")
		,
		"album3"=>array("mappa"=>"kepek/album3","alias"=>"Nyaralás a balatonon")
		);
	*/
	
	//az egyes tömbelemek kapnak egy numerikus 0-tól kezdődő indexet
	$_SESSION["albumok"]=array( 
			array("mappa"=>"kepek/album1","alias"=>"Nyári élmények")
			,
			array("mappa"=>"kepek/album2","alias"=>"Család")
			,
			array("mappa"=>"kepek/album3","alias"=>"Nyaralás a balatonon")
			);
}

?>