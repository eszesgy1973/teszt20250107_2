<?php
session_start();

if( $_POST["email"]=="eszesgy@gmail.com" and $_POST["jelszo"]=="12345" )
{
	$_SESSION["belepett"]=true;
	
	$_SESSION["aktuser"]="Eszes Gyuri";
	
	header("Location:index.php");
}
else
{
	//echo("Sikertelen belépés!");
	
	//echo("<BR><A href='belepes.php'>Vissza</A>");
	
	header("Location:index.php?login=error");
}
?>