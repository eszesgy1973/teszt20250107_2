<?php
if( isset($_GET["login"]) )
{
	if( $_GET["login"]=="error" )
	{
		echo("<DIV>Sikertelen belépés</DIV>");
	}
}

if( isset( $_SESSION["aktuser"] ) ) //ha már sikerült a bejelentkezés
{
	echo("Belépve: ".$_SESSION["aktuser"]);
	echo("<BR><A href='index.php?logout=1'>Kilépés</A>");
}
else
{
?>

<FORM action="belepellenor.php" method="POST">
<INPUT type="text" name="email" placeholder="E-mail..." class="urlapmezo">
<BR>
<INPUT type="password" name="jelszo" placeholder="Jelszó..." class="urlapmezo">
<BR>
<INPUT type="submit" Value="Belépés">
</FORM>

<?php
}
?>


