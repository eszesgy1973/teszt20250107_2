<?php
session_start();

$albumindex=$_POST["albumindex"];

$mappa=$_SESSION["albumok"][$albumindex]["mappa"];

//a feltöltött adott űrlap azonosítóval rendelkező fájl adatainak elérése
//print_r( $_FILES["kep"] );

if( $_FILES["kep"]["type"] == "image/jpeg" or $_FILES["kep"]["type"] == "image/png" )
{
	//átmozgatom a fájlt az átmeneti biztonságos mappából a végleges "kep" mappába
	move_uploaded_file( $_FILES["kep"]["tmp_name"] , $mappa."/".$_FILES["kep"]["name"] );
	//honnan , hová és milyen néven

	//automatikus átirányítás egy tetszőleges modulra vagy url-readdir
	header("Location:index.php?aloldal=gallery.php&album=".$albumindex);
}
else echo("Csak jpeg vagy png tölthető fel!<BR><A href='index.php?aloldal=gallery.php'>Vissza</A>");
?>