<?php
//létrehozunk egy tömböt amelynek minden elem egy további tömb ami asszociatív módon tartalmazza a menüpont alap tulajdonságait
$menupontok=array(
				array("felirat"=>"Home","hivatkozas"=>"home.php","style"=>"menupont")
				,
				array("felirat"=>"News","hivatkozas"=>"news.php","style"=>"menupont")
				,
				array("felirat"=>"Gallery","hivatkozas"=>"gallery.php","style"=>"menupont")
				);

foreach( $menupontok as $egymenupont )
{
	echo("<A class='".$egymenupont["style"]."' href='index.php?aloldal=".$egymenupont["hivatkozas"]."'>".$egymenupont["felirat"]."</A>");
}

?>
				