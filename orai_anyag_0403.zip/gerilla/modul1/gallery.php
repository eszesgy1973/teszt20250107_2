<?php
if( isset( $_GET["album"] ) )
	{
		$albumindex=$_GET["album"];
		//$album_mappa=$_SESSION["albumok"][$albumindex]["mappa"];
	}
	else 
	{	
		$albumindex=0;
		//$album_mappa=$_SESSION["albumok"][0]["mappa"];
	}
?>

<form enctype="multipart/form-data" action="feltoltes.php" method="POST">
Kép feltöltése az albumba:<BR>
<input type="file" name="kep">
<input type="hidden" name="albumindex" value="<?php echo($albumindex) ?>">
<input type="submit" value="Feltöltés">
</form>
<HR>

<DIV class="albumok_listaja">
	<?php
	for( $i=0;$i<count($_SESSION["albumok"]);$i++ )
	{
		echo( "<A class='galeria_link' href='index.php?aloldal=gallery.php&album=".$i."'>".$_SESSION["albumok"][$i]["alias"]."</A>&nbsp;" );
	}
	
	
	$album_mappa=$_SESSION["albumok"][$albumindex]["mappa"];
	
	//echo($album_mappa);
	
	?>
</DIV>

<HR>

<DIV class="album_cime">
	<?php
		echo( $_SESSION["albumok"][$albumindex]["alias"] );
	?>
</DIV>

<?php
//mappa megnyitása
$mappa=opendir($album_mappa);

//fájl vagy mappa bejegyzés kiolvasása
/*
$fajl=readdir($mappa); //a következő bejegyzést olvassa ki 

echo( $fajl );

$fajl=readdir($mappa); //a következő bejegyzést olvassa ki 

echo( "<BR>".$fajl );
*/

while( $fajl=readdir($mappa) ) // $fajl=readdir($mappa) -> ennek a függvénynek a hívása false értéket eredményez abban az esetben ,ha elértük az utolsó bejegyzést
{
	//echo( $fajl."<BR>" );
	if( $fajl!="." and $fajl!=".." )
	{
		echo("<IMG src='".$album_mappa."/".$fajl."' class='kiskep'>");
		echo("<A onclick='return ellenor()' href='torles.php?kep=".$fajl."&albumindex=".$albumindex."'>X</A>");
	}
}

?>

<script>
	function ellenor()
	{
		return confirm("Valóban törölni akarja a képet?");
	}
</script>