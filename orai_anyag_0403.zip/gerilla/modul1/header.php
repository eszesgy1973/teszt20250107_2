<div class="bal_panel">
	<img class="logo" src="images/logo.svg">
</div>

<div class="jobb_panel">
	<?php
		include("belepes.php");
	?>
</div>