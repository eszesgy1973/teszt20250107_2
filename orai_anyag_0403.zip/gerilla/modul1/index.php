<?php
session_start();

if( isset( $_GET["logout"] ) )
{
	session_unset();
}

/*
Bővítsük a projektet további két modullal úgy,hogy menüből hívhatóak legyenek.

A fájl feltöltés funkció felett legyen egy "album1" , "album2" , "album3" link amire kattintva a megfelelő "kepek","kepek2","kepek3" mappában lévő képek jelennek meg

*/

include("albumok.php"); //létrehozzon egy session tömböt amiben az aktuális albumok tárolódnak

?>
<!doctype html>
<html>
	<head>
		<title>Modulok a PHP-ben</title>
		<link rel="stylesheet" type="text/css" href="stilus.css">
		<meta charset="utf-8">
	</head>
	<body>
		<header>
			<?php
				include("header.php");
			?>
		</header>
		
		<nav>
			<?php
				include("fomenu.php");
			?>
		</nav>
		
		<section class="content">
			<?php
				if( isset( $_GET["aloldal"] ) )
				{
					include( $_GET["aloldal"] );
				}
				else
				include("home.php");
			?>
		</section>
		
		<footer>
		
		</footer>
	</body>
</html>