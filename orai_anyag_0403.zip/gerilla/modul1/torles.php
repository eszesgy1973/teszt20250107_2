<?php
session_start();

$albumindex=$_GET["albumindex"];

$mappa=$_SESSION["albumok"][$albumindex]["mappa"];

//fizikai fájltörlés
unlink($mappa."/".$_GET["kep"]);

header("Location:index.php?aloldal=gallery.php&album=".$albumindex);
?>