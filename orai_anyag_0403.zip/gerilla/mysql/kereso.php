<form action="telefonkonyv.php" method="POST">
<input type="text" name="keres_nev" placeholder="Keresés névre...">
<button type="submit">?</button>
</form>