<?php
$kapcsolat=new mysqli("localhost","root","","gerilla");
/* mysql szerver neve,felhasználó,jelszó,adatbázis neve */

$kapcsolat->query("set names utf8"); //utf-8 kommunikáció beállítása

//adott record vagy recordok módosítása
/*
update tábla neve set mezőnév=új érték , mezőnév2=új érték2 where feltétel

Módosítsd az adott tábla adott mezőit a megadott értékre mindenhol ahol a feltétel igaz

pl: update telefonkonyv set mobil='0630456788' where id=23
*/

$st=$kapcsolat->prepare("update telefonkonyv set mobil=? where id=?");

$st->bind_param("sd" , $_POST["mod_mobil"],$_POST["id"]);

if( $st->execute() ) //parancs futtatása -> execute()
{
	header("Location:telefonkonyv.php");
}
else echo("hiba");
?>