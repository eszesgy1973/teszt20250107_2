<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="stilus.css">

<?php
/*
HF: bővítsük a táblát egy plusz mezővel pl. munkahelyi telefon és kezeljük is le kliens oldalon
*/

$kapcsolat=new mysqli("localhost","root","","gerilla");
/* mysql szerver neve,felhasználó,jelszó,adatbázis neve */

$kapcsolat->query("set names utf8"); //utf-8 kommunikáció beállítása

if($kapcsolat) /*ha sikeres a csatlakozás*/
{
	//echo("Sikeres csatlakozás az adatbázis szerverhez!");
	
	if(isset($_GET["sorba"]))
	{
		$sorbarend=" order by ".$_GET["sorba"]." ".$_GET["irany"]; /*DESC -> csökkenő sorrendbe adja vissza , ASC ->növekvő sorrendben*/
	}
	else $sorbarend=" order by nev";
	
	/*
	select * from telefonkonyv where cim="Pest" -> csak a pontos egyezéseket adja vissza
	
	select * from telefonkonyv where cim like "%Pest%" -> azokat az egyezéseket adja vissza ahol szerepel valahol a mezőben a Pest karakterlánc
	
	*/
	
	if( isset($_POST["keres_nev"]) )
	{
		$feltetel=" where nev like '%".$_POST["keres_nev"]."%'";
	}
	else $feltetel="";
	
	//parancs küldése a mysql szerver irányába
	$vissza=$kapcsolat->query("select * from telefonkonyv".$feltetel.$sorbarend); //add vissza a telefonkonyv tábla összes adatát
	//$vissza -> ebbe a változóba érkezik meg a teljes visszaadott eredményhalmaz
	
	//sorok vagy record-ok kiolvasása
	//$sor=mysqli_fetch_array($vissza); //kiolvassuk egy asszociatív tömbbe az első record adatait
	
	//adatok kiolvasása vagy hivatkozás az adatra
	//echo( "<HR>".$sor["nev"]." , ".$sor["mobil"] );
	
	//eredményhalmaz sorainak a száma
	echo("<MARQUEE>Jelenleg a telefonkönyvben <B><FONT color='red'>".mysqli_num_rows($vissza)."</FONT></B> személy található </MARQUEE>");
	
	include("kereso.php");
}

if(isset($_GET["irany"]))
{
	if( $_GET["irany"]=="ASC" )
	{
		$irany="DESC";
	}
	else $irany="ASC";
}
else $irany="DESC";

?>

<TABLE cellpadding="0px" cellspacing="0px">
	<TR>
		<TH><a href="telefonkonyv.php?sorba=nev&irany=<?php echo $irany?>">Név</a></TH>
		<TH>Mobilszám</TH>
		<TH>E-mail</TH>
		<TH><a href="telefonkonyv.php?sorba=cim&irany=<?php echo $irany?>">Cím</a></TH>
		<TH></TH>
	</TR>
	
	<?php
	while( $sor=mysqli_fetch_array($vissza) )
	{
		echo("<form action='modosit.php' method='POST'>");
		
		echo("<TR>");
			echo("<TD>");
			echo($sor["nev"]);
			echo("</TD>");
			
			echo("<TD>");
			echo("<input type='text' style='width:100%' name='mod_mobil' value='".$sor["mobil"]."'>");
			echo("</TD>");
			
			echo("<TD>");
			echo($sor["email"]);
			echo("</TD>");
			
			echo("<TD>");
			echo($sor["cim"]);
			echo("</TD>");
			
			echo("<TD>");
			echo("<A onclick='return ellenor()' href='torles.php?id=".$sor["id"]."'>Törlés</A>");
			echo("</TD>");
			
			echo("<input type='hidden' name='id' value='".$sor["id"]."'>");
			
			echo("<TD><button type='submit'>Módosítás</button></TD>");
			
		echo("</TR></form>");	
			
	}
	?>
</TABLE>	

<?php
	include("ujszemely.php");
?>
		
<SCRIPT>
	function ellenor()
	{
		return confirm("Valóban törölni akarja a bejegyzést?");
	}
</SCRIPT>		
		