<?php
$kapcsolat=new mysqli("localhost","root","","gerilla");
/* mysql szerver neve,felhasználó,jelszó,adatbázis neve */

$kapcsolat->query("set names utf8"); //utf-8 kommunikáció beállítása

/*
fizikai törlés a táblából

delete from tábla neve where feltétel -> töröld a feltételnek megfelelő record-okat , ha nincs where mindent töröl

pl: delete from telefonkonyv where id=22

delete from telefonkonyv where cim="Vecsés"

delete from telefonkonyv where cim like "%Vecsés%" -> tartalmazza a Vecsés karakterláncot és előtte vagy utánna tetszőleges kearkterek lehetnek 

*/

$pcs="delete from telefonkonyv where id='".$_GET["id"]."'";

if( $kapcsolat->query($pcs) ) //ha igaz akkor a parancs végrehajtásra került
{
	header("Location:telefonkonyv.php");
}
else
{
	echo("Hiba!");
}

?>