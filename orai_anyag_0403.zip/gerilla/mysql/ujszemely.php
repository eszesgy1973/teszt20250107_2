<fieldset class="urlap_keret">

	<legend>Új személy felvitele</legend>

	<FORM action="ujszemely_ment.php" method="POST">
	<input type="text" name="ujnev" placeholder="Név...">
	<br>
	<input type="text" name="ujmobil" placeholder="Telefonszám...">
	<br>
	<input type="text" name="ujcim" placeholder="Cím...">
	<br>
	<input type="email" name="ujemail" placeholder="E-mail...">
	<br>
	<input type="submit" Value="Mentés">
	</FORM>
	
</fieldset>