<?php
$kapcsolat=new mysqli("localhost","root","","gerilla");
/* mysql szerver neve,felhasználó,jelszó,adatbázis neve */

$kapcsolat->query("set names utf8"); //utf-8 kommunikáció beállítása

/*
új record hozzáadása SQL

insert into tábla neve (mezők) values (értékek) 

fontos: az értékek sorrend és tipushelyes módon legyenek felsorolva

pl: insert into telefonkonyv (nev,mobil,cim,email) values ('Gyuri','06302480034','Szolnok','eszesgy@gmail.com')

*/

$pcs="insert into telefonkonyv (nev,mobil,cim,email) values ('".$_POST["ujnev"]."','".$_POST["ujmobil"]."','".$_POST["ujcim"]."','".$_POST["ujemail"]."')";

echo($pcs);

if( $kapcsolat->query($pcs) ) //ha igaz akkor a parancs végrehajtásra került
{
	header("Location:telefonkonyv.php");
}
else
{
	echo("Hiba!");
}

?>