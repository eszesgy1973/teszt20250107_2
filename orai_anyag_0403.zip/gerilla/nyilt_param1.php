<?php
$szam1=$_GET["sz1"]; //$_GET -> a nyíltan átadott paraméterek tárolója
// $_GET[paraméter neve]

$szam2=$_GET["sz2"];

echo("Az átadott paraméter értéke:".$szam1);
echo("<HR>");
echo( $szam1."+".$szam2."=".($szam1+$szam2) );
?>