<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<?php
echo("<FORM action='nyilt_param_form.php' method='GET'>");
echo("Válaszd ki a képet:<BR>");
echo("<SELECT name='kep'>");
echo("<OPTION value='kep1.jpg'>Kutya1</OPTION>");
echo("<OPTION value='kep2.jpg'>Kutya2</OPTION>");
echo("<OPTION value='kep3.jpg'>Kutya3</OPTION>");
echo("</SELECT><BR>");

echo("<INPUT type='submit' Value='Mutasd'>");
echo("</FORM>");

echo("<HR>");

// változó vagy átadott paraméter létezésének vizsgálata -> isset( paraméter) -> true értékkel tér vissza ,ha a változó létezik és false ha nem
if( isset($_GET["kep"]) ) //ha a feltétel igaz vagyis létezik a $_GET["kep"] akkor lefut az elágazás magja
{
	echo("<IMG src='kepek/".$_GET["kep"]."' class='nagykep'>");
}

?>