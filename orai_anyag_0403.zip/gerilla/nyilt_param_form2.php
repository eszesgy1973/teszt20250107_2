<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<FORM action='nyilt_param_form2.php' method='GET'>
Válaszd ki a képet:<BR>
<SELECT name='kep'>
<OPTION value='kep1.jpg'>Kutya1</OPTION>
<OPTION value='kep2.jpg'>Kutya2</OPTION>
<OPTION value='kep3.jpg'>Kutya3</OPTION>
</SELECT><BR>

<INPUT type='submit' Value='Mutasd'>
</FORM>
<HR>

<?php
// változó vagy átadott paraméter létezésének vizsgálata -> isset( paraméter) -> true értékkel tér vissza ,ha a változó létezik és false ha nem
if( isset($_GET["kep"]) ) //ha a feltétel igaz vagyis létezik a $_GET["kep"] akkor lefut az elágazás magja
{
	echo("<IMG src='kepek/".$_GET["kep"]."' class='nagykep'>");
}
?>