<?php
session_start();

if( isset($_GET["logout"]) )
{
	unset($_SESSION["aktuser"]); //adattag törlése a session-hez kapcsolt tárolóból
}

if( isset( $_SESSION["aktuser"] ) )
{
	echo("Belépve: ".$_SESSION["aktuser"]);
	echo("<BR><A href='aktuser.php?logout=1'>Kilépés</A>");
}
else echo("Nincs bejelentkezett felhasználó!");
?>