<?php
session_start();

//if( isset($_GET["logout"]) ) unset( $_SESSION["belepett"] );

if( isset($_GET["logout"]) ) session_unset(); //komplett session tároló törlése

if( isset($_SESSION["belepett"]) )
{
	echo("Belépve: ".$_SESSION["aktuser"]);
	
	echo("<BR><A href='belepes.php?logout=1'>Kilépés</A>");
	
	echo("<HR>Ide jöhet az a tartalom amit csak a belépett user láthat!"); 
}
else
{
?>

<FORM action="belepellenor.php" method="POST">
<INPUT type="text" name="email" placeholder="E-mail...">
<BR>
<INPUT type="password" name="jelszo" placeholder="Jelszó...">
<BR>
<INPUT type="submit" Value="Belépés">
</FORM>

<?php
}
?>