<?php
//session tároló használatba vétele: A munkamenethez kapcsolható egy tároló amely valójában egy asszociatív tömb.
//a hozzáféréshez szükséges a kód elején egy session_start() függvényhívás
session_start();

//adat letárolása a session tárolóban
$_SESSION["aktuser"]="Gyuri";

//a létrehozott session változó addig létezik amíg a felhasználó fenntartja a kapcsolatot a szerverrel.
//ha bezárom a böngészőt akkor a szerver oldali session tároló törlődik
//újboli fellépést követően viszont egy új session és ahhoz kapcsolódó tároló keletkezik.

echo("Belépve: ".$_SESSION["aktuser"]);

?>