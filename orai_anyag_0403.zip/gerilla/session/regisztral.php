<?php
	session_start();
?>
<!doctype html>
<html>
	<head>
		<title>Regisztráció és session-ök</title>
		<link rel="stylesheet" type="text/css" href="stilus.css">
	</head>
	<body>
		<div class="urlapkeret">
			<?php
			$nev="";
			$email="";
			
			if( isset($_SESSION["hibak"]) )
			{
				foreach( $_SESSION["hibak"] as $egyhiba )
				{
					echo("<DIV class='hibadoboz'>".$egyhiba."</DIV>");
				}
				
				$nev=$_SESSION["regadatok"]["regnev"];
				$email=$_SESSION["regadatok"]["regemail"];
				//$_SESSION["regadatok"] -> tömb aminek az elemei a $_POST tömb adatai
			}
			?>
			<form action="regment.php" method="POST">
			<input type="text" name="regnev" placeholder="Név..." class="urlapmezo" value="<?php echo($nev)?>">
			<input type="email" name="regemail" placeholder="E-mail..." class="urlapmezo" value="<?php echo($email)?>">
			<input type="password" name="regjelszo" placeholder="Jelszó..." class="urlapmezo">
			<input type="password" name="regjelszo2" placeholder="Jelszó újra..." class="urlapmezo">
			<input type="text" name="mobilszam" placeholder="Mobil..." class="urlapmezo">
			<input type="submit" Value="Mentés" class="urlapmezo gomb">
			</form>
		</div>
	</body>
</html>
			