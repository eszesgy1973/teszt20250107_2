<?php
session_start();

$hibak=array();

if( trim($_POST["regnev"]) == "" ) //nincs kitöltve a név
{
	array_push( $hibak , "Név kitöltése kötelező!" );
}

if( trim($_POST["regjelszo"]) == "" ) //nincs kitöltve jelszó
{
	array_push( $hibak , "Nincs jelszó!" );
}

//hasonlítsuk össze a jelszó és a jelszó újra mezők tartalmát és ha nem egyezik akkor hibaüzenet  

//Amennyiben a $hibak tömb tartalmaz elemet akkor visszairányítjuk,de előtte a $hibak tömböt betöltjük egy session változóba

if( count($hibak) > 0 ) //count(tömb) -> visszaadja a tömb elemeinek számát
{
	$_SESSION["hibak"]=$hibak;
	
	$_SESSION["regadatok"]=$_POST;
	
	header("Location:regisztral.php");
}
else
{
	//if( isset($_SESSION["hibak"]) ) { unset($_SESSION["hibak"]); }
	if( isset($_SESSION["hibak"]) ) { session_unset(); }
	
	echo("Minden rendben.Mentjük valahová!");
}
?>