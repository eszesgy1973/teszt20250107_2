<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<form action="szamologep.php" method="POST"> <!-- a post rejtett módon küldi az ürlap adatokat vagyis nem látszik az URL-ben -->
<input type="number" name="sz1" value="0">
<BR>
<input type="number" name="sz2" value="0">
<BR>
<input type="submit" value="+">
</form>

<?php
if( isset($_POST["sz1"]) )
{
	echo("<HR>".$_POST["sz1"]."+".$_POST["sz2"]."=".($_POST["sz1"]+$_POST["sz2"]));
}	
?>