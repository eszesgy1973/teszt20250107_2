<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<form action="szamologep2.php" method="POST"> <!-- a post rejtett módon küldi az ürlap adatokat vagyis nem látszik az URL-ben -->
<input type="number" name="sz1" value="0">
<BR>
<input type="number" name="sz2" value="0">
<BR>
<input type="radio" name="muvelet" checked value="1">+
<input type="radio" name="muvelet" value="2">-
<input type="radio" name="muvelet" value="3">*
<input type="radio" name="muvelet" value="4">/
<BR>
<input type="submit" value="=">
</form>

<?php
if( isset($_POST["sz1"]) )
{
	if( $_POST["muvelet"]=="1" )
	{
		echo("<HR>".$_POST["sz1"]."+".$_POST["sz2"]."=".($_POST["sz1"]+$_POST["sz2"]));
	}
	
	if( $_POST["muvelet"]=="2" )
	{
		echo("<HR>".$_POST["sz1"]."-".$_POST["sz2"]."=".($_POST["sz1"]-$_POST["sz2"]));
	}
	
	if( $_POST["muvelet"]=="3" )
	{
		echo("<HR>".$_POST["sz1"]."*".$_POST["sz2"]."=".($_POST["sz1"]*$_POST["sz2"]));
	}
	
	if( $_POST["muvelet"]=="4" )
	{
		if( $_POST["sz2"]!="0" )
		{
			echo("<HR>".$_POST["sz1"]."/".$_POST["sz2"]."=".($_POST["sz1"]/$_POST["sz2"]));
		}
		else echo("Nullával történő osztás!");
	}
}	
?>