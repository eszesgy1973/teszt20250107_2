<?php
$pizzak="kukoricás;sonkás;négy évszak;hawaii";

//szeparált szöveg tömbbé alakítása
$pizzak_tomb=explode(";",$pizzak);

echo("<TABLE border='1px'>");

foreach( $pizzak_tomb as $elem )
{
	echo("<TR><TD>".$elem."</TD></TR>");
}

echo("</TABLE>");
?>