<?php
//fájl tartalmának beolvasása egy változóba
$szoveg=file_get_contents("telefonkonyv.txt");

//echo($szoveg);

//A szöveg sorokra bontása: \n -> sortörés karakter
$sorok=explode("\n",$szoveg);

echo("<TABLE border='1px'>");
echo("<TR><TD>Név</TD><TD>Cím</TD><TD>Telefonszám</TD></TR>");
foreach( $sorok as $egysor )
{
	echo("<TR>");
	
	//azért ,hogy külön td-ben tudjam megjeleníteni az adattagokat ; alapján kell tovább bontanom a $egysor-t
	$adatok=explode(";",$egysor);
	
	echo("<TD>".$adatok[0]."</TD>"); //ez gyakorlatilag hivatkozás a névre
	echo("<TD>".$adatok[1]."</TD>"); //ez gyakorlatilag hivatkozás a címre
	echo("<TD>".$adatok[2]."</TD>"); //ez gyakorlatilag hivatkozás a telefonszám
	
	//echo($egysor);
	echo("</TR>");
}
echo("</TABLE>");
?>