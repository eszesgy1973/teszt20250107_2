<?php
//mi a tömb? Azonos típusú adatok,rendezett egyedileg is elérhető tárolási struktúrája a memóriában

//tömb létrehozása
$tomb1=array("Hapci","Vidor","Tudor","Kuka");

//tömb egy adott elemének elérése: tomb_neve[index] -> index 0-tól indul
echo( $tomb1[0] );

//elem hozzáadása a tömb végéhez
array_push($tomb1,"Szende");

echo( "<BR>".$tomb1[4] );

//elem törlése a tömbből : annak ellenére,hogy az adott index megszünik a megmaradt elemek indexe nem változik
unset( $tomb1[0] );

//$tomb1[0]="Szundi";

$tomb1=array_values($tomb1); //tömb újraindexelése

echo( "<BR>".$tomb1[0] );

echo("<HR>");

//tömb bejárása
foreach( $tomb1 as $elem ) //kiolvassa indextől függetlenül a következő tömbelemet és betölti a megadott változóba,addig fut amíg az összes elemet ki nem olvasta
{
	echo($elem." , ");
}	

?>