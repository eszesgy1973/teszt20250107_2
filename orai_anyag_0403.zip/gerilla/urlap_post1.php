<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="css/stilus.css">

<form action="feldolgoz.php" method="POST"> <!-- a post rejtett módon küldi az ürlap adatokat vagyis nem látszik az URL-ben -->
<input type="text" name="vnev" placeholder="Vezetéknév...">
<BR>
<input type="text" name="knev" placeholder="Keresztnév...">
<BR>
<input type="submit" value="Belépés">
</form>