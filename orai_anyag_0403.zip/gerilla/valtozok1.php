<?php
//változó létrehozása
// $változó neve = alapérték;

$szam1=15;

$szam2=25;

echo("A szam1 és a szam2 összege:".($szam1+$szam2));

echo("<HR>");

echo( $szam1."+".$szam2."=".($szam1+$szam2) );

?>